import os, tempfile, unittest
from pathlib import Path
class TestCyberAware(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        os.environ['DATABASE_PATH']=str(Path(cls.tmp.name)/'test.sqlite3')
        os.environ['ADMIN_EMAIL']='admin@example.com'
        os.environ['ADMIN_PASSWORD']='LongSafeAdminPass!2026'
        from app import app,db
        cls.app=app
        cls.app.config['TESTING']=True
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def setUp(self):self.client=self.app.test_client()
    def csrf(self):
        with self.client.session_transaction() as s:return s['csrf']
    def admin(self):
        self.client.get('/login')
        return self.client.post('/login',data={'_csrf':self.csrf(),'email':'admin@example.com','password':'LongSafeAdminPass!2026'},follow_redirects=True)
    def test_admin_employee_and_assignment(self):
        resp=self.admin();self.assertIn(b'Employee Training Management',resp.data)
        r=self.client.post('/admin/employees/new',data={'_csrf':self.csrf(),'name':'Training User','email':'training@example.com','modules':['1','4']})
        self.assertIn(b'Account ready',r.data)
        with self.app.app_context():
            from app import db
            emp=db().execute("SELECT * FROM users WHERE email=?",('training@example.com',)).fetchone()
            self.assertEqual(2,db().execute('SELECT count(*) FROM assignments WHERE user_id=?',(emp['id'],)).fetchone()[0])
            uid=emp['id']
        r=self.client.post(f'/admin/employees/{uid}/edit',data={'_csrf':self.csrf(),'name':'Training User','email':'training2@example.com','modules':['2']},follow_redirects=True)
        self.assertIn(b'Training User',r.data)
        with self.app.app_context():
            self.assertEqual({2}, {x['module_id'] for x in db().execute('SELECT module_id FROM assignments WHERE user_id=?',(uid,))})
        r=self.client.post(f'/admin/employees/{uid}/reset',data={'_csrf':self.csrf()})
        self.assertIn(b'Temporary password',r.data)
        self.assertEqual(403,self.client.get('/training/1').status_code)
    def test_csrf(self):
        self.admin()
        self.assertEqual(400,self.client.post('/admin/employees/new',data={'name':'Fake'}).status_code)
    def test_health(self):self.assertEqual(200,self.client.get('/health').status_code)
if __name__=='__main__':unittest.main()
