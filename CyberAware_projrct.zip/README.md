# CyberAware – Student Feedback Update

Full runnable standalone Flask application for the feedback, with 6 cybersecurity learning modules, explanations and colourful diagrams.

## Features
- Three scored multiple-choice questions for each of the six modules, stored per employee with latest scores
- Employee quiz list and module quiz results; unassigned quiz URLs blocked

- Admin-only employee account creation; random employee temporary passwords shown only once
- Mandatory new-employee password change
- Edit employee name/email, assign any 1–6 lessons, reset password, delete employee
- Employee login only displays assigned modules; unassigned module URLs are denied
- Completion tracking and admin progress totals
- Passwords stored as salted password hashes; role enforcement and CSRF protection
- Admin login with a password **set at deployment/runtime via ADMIN_PASSWORD** (not hardcoded). One-time admin OTP is **not** implemented: the audio suggested either an OTP or a runtime-defined password.

## Run locally (Windows PowerShell)
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:SECRET_KEY = "replace-with-a-long-random-secret"
$env:ADMIN_EMAIL = "admin@example.com"
$env:ADMIN_PASSWORD = "ChooseYourOwnLongAdminPassword!2026"
python app.py
```
Go to http://127.0.0.1:5000 and log in with the admin email/password **you configured**.

## Deploy on Render
1. BACK UP the existing site database before deployment. This is a standalone version and will not automatically migrate old SQLAlchemy records. Extract ZIP and push contents to GitHub (repository root contains `app.py`).
2. Create a Render **Web Service** from the repository. Build: `pip install -r requirements.txt`; Start: `gunicorn app:app --bind 0.0.0.0:$PORT`.
3. Add environment variables `SECRET_KEY` (long random value), `ADMIN_EMAIL` (your login email), `ADMIN_PASSWORD` (your own 12+ character password), and `COOKIE_SECURE=1`.
4. On first deployment, your admin account is created from those values. Open the Render URL and sign in. This setup does **not** replace an existing admin password in an old database; use a fresh database for a new deployment.
5. **Production storage:** configure `DATABASE_PATH` to an attached persistent disk location. Render ephemeral files are wiped on rebuild/restart. If the Render plan doesn't support a persistent disk, migrate the app to a hosted persistent database before storing real staff data. This example uses SQLite and is suitable for a small demo/testing, not a scaled multi-instance production deployment.
6. If updating an existing service, deploy this repo and environment variables; there is no guarantee its previous database or app templates are compatible with this standalone rewrite. Keep backups and test separately before migrating.

## Important
- Never paste real passwords in public chat or code or commit an `.env` file.
- An admin password in environment variables bootstraps the **first** admin only. The admin can change it from the site afterwards.
- Share employee credentials privately. Employees must change temporary passwords before accessing their training.
- Changing modules preserves prior completion records but the dashboard counts only modules currently assigned.
